document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('addButton').addEventListener('click', addTask);
    document.getElementById('shareButton').addEventListener('click', generateShareableLink);

    // If there is a URL with encoded tasks, load them
    if (window.location.search) {
        const params = new URLSearchParams(window.location.search);
        const tasksParam = params.get('tasks');
        if (tasksParam) {
            const tasks = JSON.parse(decodeURIComponent(tasksParam));
            tasks.forEach(task => createTaskElement(task));
        }
    }

    function addTask() {
        const taskInput = document.getElementById('taskInput');
        const deadlineInput = document.getElementById('deadlineInput');
        const taskName = taskInput.value.trim();
        const deadlineDate = new Date(deadlineInput.value);

        if (taskName === "" || !deadlineDate.getTime()) {
            alert("Please enter a valid task and deadline.");
            return;
        }

        const task = {
            name: taskName,
            deadline: deadlineDate,
            completed: false
        };

        createTaskElement(task);

        // Clear inputs after adding the task
        taskInput.value = '';
        deadlineInput.value = '';
    }

    function createTaskElement(task) {
        const taskList = document.getElementById('taskList');
        const li = document.createElement('li');
        li.classList.add('flex', 'items-center', 'justify-between', 'p-2', 'border', 'rounded-md', 'shadow-sm');

        const taskName = document.createElement('span');
        taskName.textContent = `${task.name} (${task.deadline.toLocaleDateString()})`;
        taskName.classList.add('flex-1');
        taskName.setAttribute('id', `taskName-${task.name}`);

        const statusButton = document.createElement('button');
        statusButton.textContent = task.completed ? 'Completed' : 'Mark as Completed';
        statusButton.classList.add('bg-green-500', 'text-white', 'px-2', 'rounded-md', 'ml-2');
        statusButton.addEventListener('click', () => toggleCompletion(task, li));

        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.classList.add('bg-yellow-500', 'text-white', 'px-2', 'rounded-md', 'ml-2');
        editButton.addEventListener('click', () => editTask(task, taskName, li));

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.classList.add('bg-red-500', 'text-white', 'px-2', 'rounded-md');
        deleteButton.addEventListener('click', () => deleteTask(li));

        li.appendChild(taskName);
        li.appendChild(statusButton);
        li.appendChild(editButton);
        li.appendChild(deleteButton);

        updateTaskAppearance(task, li);
        taskList.appendChild(li);
    }

    function toggleCompletion(task, li) {
        task.completed = !task.completed;
        updateTaskAppearance(task, li);
    }

    function updateTaskAppearance(task, li) {
        const today = new Date();
        const isOverdue = task.deadline < today && !task.completed;
        const isDueTodayOrFuture = task.deadline >= today && !task.completed;

        if (task.completed) {
            li.classList.add('bg-green-200');
            li.classList.remove('bg-red-200', 'bg-blue-200');
        } else if (isOverdue) {
            li.classList.add('bg-red-200');
            li.classList.remove('bg-blue-200', 'bg-green-200');
        } else if (isDueTodayOrFuture) {
            li.classList.add('bg-blue-200');
            li.classList.remove('bg-red-200', 'bg-green-200');
        }
    }

    function deleteTask(li) {
        li.remove();
    }

    function editTask(task, taskName, li) {
        const input = document.createElement('input');
        input.type = 'text';
        input.value = task.name;
        input.classList.add('p-2', 'border', 'border-gray-300', 'rounded-md');

        const saveButton = document.createElement('button');
        saveButton.textContent = 'Save';
        saveButton.classList.add('bg-green-500', 'text-white', 'px-2', 'rounded-md', 'ml-2');
        saveButton.addEventListener('click', () => saveTaskEdit(task, input, saveButton, taskName, li));

        taskName.replaceWith(input);
        const editButton = li.querySelector('button.bg-yellow-500');
        editButton.replaceWith(saveButton);
    }

    function saveTaskEdit(task, input, saveButton, taskName, li) {
        const newName = input.value.trim();

        if (newName !== "") {
            task.name = newName;
            taskName.textContent = `${task.name} (${task.deadline.toLocaleDateString()})`;
        }

        input.replaceWith(taskName);
        saveButton.replaceWith(createEditButton(task, taskName, li));

        updateTaskAppearance(task, li);
    }

    function createEditButton(task, taskName, li) {
        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.classList.add('bg-yellow-500', 'text-white', 'px-2', 'rounded-md', 'ml-2');
        editButton.addEventListener('click', () => editTask(task, taskName, li));
        return editButton;
    }

    function generateShareableLink() {
        const taskList = Array.from(document.getElementById('taskList').children);
        const tasks = taskList.map(taskElement => {
            const taskName = taskElement.querySelector('span').textContent.split(' (')[0];
            const deadline = taskElement.querySelector('span').textContent.match(/\(([^)]+)\)/)[1];
            const completed = taskElement.querySelector('button').textContent === 'Completed';
            return {
                name: taskName,
                deadline: new Date(deadline),
                completed: completed
            };
        });

        const tasksParam = encodeURIComponent(JSON.stringify(tasks));
        const shareLink = `${window.location.origin}${window.location.pathname}?tasks=${tasksParam}`;

        // Display the shareable link
        document.getElementById('shareLink').value = shareLink;
    }
});
