document.getElementById('addTaskBtn').addEventListener('click', addTask);

function addTask() {
  const taskTitle = document.getElementById('taskTitle').value.trim();
  const dueDate = document.getElementById('dueDate').value;

  if (!taskTitle || !dueDate) return; // Don't add empty tasks

  const task = {
    title: taskTitle,
    dueDate: new Date(dueDate),
    completed: false,
  };

  saveTask(task);
  displayTasks();
  resetForm();
}

function saveTask(task) {
  const tasks = getTasks();
  tasks.push(task);
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

function getTasks() {
  const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  return tasks.map(task => ({
    ...task,
    dueDate: new Date(task.dueDate)
  }));
}

function displayTasks() {
  const taskList = document.getElementById('taskList');
  taskList.innerHTML = ''; // Clear current task list

  const tasks = getTasks();
  tasks.forEach((task, index) => {
    const taskElement = document.createElement('li');
    taskElement.classList.add('task', 'p-4', 'rounded', 'border', 'flex', 'justify-between', 'items-center');
    taskElement.classList.add(getTaskStatusClass(task));

    const taskTitle = document.createElement('span');
    taskTitle.textContent = task.title;

    const taskDate = document.createElement('span');
    taskDate.textContent = `Due: ${task.dueDate.toLocaleString()}`;

    const completeButton = document.createElement('button');
    completeButton.textContent = task.completed ? 'Undo' : 'Complete';
    completeButton.classList.add('p-2', 'bg-green-500', 'text-white', 'rounded');
    completeButton.addEventListener('click', () => toggleCompletion(task, index));

    taskElement.appendChild(taskTitle);
    taskElement.appendChild(taskDate);
    taskElement.appendChild(completeButton);

    taskList.appendChild(taskElement);
  });
}

function toggleCompletion(task, index) {
  task.completed = !task.completed;
  const tasks = getTasks();
  tasks[index] = task;
  localStorage.setItem('tasks', JSON.stringify(tasks));
  displayTasks();
}

function getTaskStatusClass(task) {
  const now = new Date();
  if (task.completed) return 'bg-green-200';
  if (task.dueDate < now) return 'bg-red-200';
  if (task.dueDate.toDateString() === now.toDateString()) return 'bg-orange-200';
  return 'bg-blue-200';
}

function resetForm() {
  document.getElementById('taskTitle').value = '';
  document.getElementById('dueDate').value = '';
}

window.onload = displayTasks;
